<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Oglas koji ste pratili je ugasen</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            color: #333;
            line-height: 1.6;
        }

        /* Add more styles as needed */
    </style>
</head>
<body>
<p>
    Postovani,
</p>
<p>
    Obavestavamo Vas da je oglas pod naslovom {{$ad->title}}  ,koji ste pratili, ugasen jer je korisnik postavio obrisao oglas ili ugasio aktivnost oglasa(proizvod je prodat).

</p>
<p>
    Hvala Vam sto koristite nasu platformu!
</p>
<p>
    Srdacan pozdrav,<br>
    Trkacka berza, <br>
    Racing-corner,
</p>
</body>
</html>
