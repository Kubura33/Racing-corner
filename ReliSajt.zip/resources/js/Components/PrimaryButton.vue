<template>
    <button
class="btn btn-secondary"
    >
        <slot />
    </button>
</template>
