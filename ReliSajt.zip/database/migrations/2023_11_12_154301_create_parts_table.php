<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('parts', function (Blueprint $table) {
            $table->id();
            $table->text('description');
            $table->text('manufacter')->nullable();
            $table->string('type')->default('other');
            $table->string('dot')->nullable();
            $table->string('number_of_tires')->nullable();
            $table->string('dimensions')->nullable();
            $table->string('isNew')->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('parts');
    }
};
