<template>
    <div class="banner">
    </div>
    <div class="conteiner">
        <div class="o_nama" style="display: flex;flex-direction: column; gap: 1em; padding: 3%; font-size: 27px;">
            <span>
                Naša platforma je specijalno dizajnirana kako bismo trkačima na Balkanu pružili jednostavan i efikasan
                način za kupovinu i prodaju delova, opreme, guma i automobila. Odlučili smo stvoriti
                prostor koji će olakšati povezivanje trkačke zajednice i omogućiti im jednostavno obavljanje trgovinskih
                poslova.
            </span>
            <span>
                 Naš sajt omogućava korisnicima da kreiraju oglase za svoje proizvode ili automobile, a zatim ih lako
                dele s ostalim članovima zajednice. Uz mogućnost praćenja drugih oglasa, korisnici mogu biti u toku s
                ponudama i potražnjom za željenim proizvodima. Verujemo da će ova platforma postati centralno mesto za
                sve trkače na Balkanu, omogućavajući im da pronađu ono što im je potrebno ili prodaju nepotrebne stvari.
            </span>
            <span>
                S obzirom na to da mnogi trkači trenutno koriste Facebook grupe za komunikaciju i deljenje oglasa,
                verujemo da će naša platforma doneti dodatnu vrednost, nudeći pregledniji, organizovaniji i sigurniji
                prostor za trgovinu. Bezbednost i jednostavnost korišćenja su nam prioriteti, te smo uložili napore kako
                bismo osigurali da svaki korisnik ima pozitivno iskustvo na našem sajtu.
            </span>
            <span>
                 Ukoliko želite da budete deo ove trkačke zajednice i da olakšate proces kupovine i prodaje trkačkih
                stvari, pridružite nam se! Registrovanjem na našem sajtu, postajete deo brze i efikasne trkačke mreže na
                Balkanu. Hvala vam što podržavate našu stranicu, i želimo vam uzbudljivo iskustvo u trgovini trkačkim
                delovima, opremom i automobilima!
            </span>
<!--            <p style="padding: 5%; font-size: 27px;">Dobrodošli na našu trkačku zajednicu!-->

<!--                Naša platforma je specijalno dizajnirana kako bismo trkačima na Balkanu pružili jednostavan i efikasan-->
<!--                način za kupovinu i prodaju delova, opreme, guma i automobila. Prijatelj i ja smo smo odlučili stvoriti-->
<!--                prostor koji će olakšati povezivanje trkačke zajednice i omogućiti im jednostavno obavljanje trgovinskih-->
<!--                poslova.-->
<!--                <br>-->
<!--                Naš sajt omogućava korisnicima da kreiraju oglase za svoje proizvode ili automobile, a zatim ih lako-->
<!--                dele s ostalim članovima zajednice. Uz mogućnost praćenja drugih oglasa, korisnici mogu biti u toku s-->
<!--                ponudama i potražnjom za željenim proizvodima. Verujemo da će ova platforma postati centralno mesto za-->
<!--                sve trkače na Balkanu, omogućavajući im da pronađu ono što im je potrebno ili prodaju nepotrebne stvari.-->
<!--                <br>-->
<!--                S obzirom na to da mnogi trkači trenutno koriste Facebook grupe za komunikaciju i deljenje oglasa,-->
<!--                verujemo da će naša platforma doneti dodatnu vrednost, nudeći pregledniji, organizovaniji i sigurniji-->
<!--                prostor za trgovinu. Bezbednost i jednostavnost korišćenja su nam prioriteti, te smo uložili napore kako-->
<!--                bismo osigurali da svaki korisnik ima pozitivno iskustvo na našem sajtu.-->
<!--                <br>-->
<!--                Ukoliko želite da budete deo ove trkačke zajednice i da olakšate proces kupovine i prodaje trkačkih-->
<!--                stvari, pridružite nam se! Registrovanjem na našem sajtu, postajete deo brze i efikasne trkačke mreže na-->
<!--                Balkanu. Hvala vam što podržavate našu stranicu, i želimo vam uzbudljivo iskustvo u trgovini trkačkim-->
<!--                delovima, opremom i automobilima!</p>-->
        </div>
    </div>
</template>
<script setup>

</script>
